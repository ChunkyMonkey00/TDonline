const roomCode = localStorage.getItem("roomCode");
const role = localStorage.getItem("role");
// Display the room code stored in localStorage
document.getElementById("code").innerText = roomCode;

// Show the chat box
const chatBox = document.getElementById("chatBox");
chatBox.style.display = "block";
let timeout;

chatBox.onmouseover = () => {
  chatBox.style.opacity = "1";
  clearTimeout(timeout);
};

chatBox.onmouseleave = () => {
  timeout = setTimeout(() => {
    chatBox.style.opacity = "0.1";
  }, 2000);
};

var username = localStorage.getItem("username") || "New User";
var piesocket;
var channel;
var UID;

// Connect to the chat using the provided PieHost code
async function connectChat() {
  piesocket = new PieSocket.default({
    clusterId: "free.blr2", // I have no clue what "free.blr2" means, but here we are.
    apiKey: "Adfa5neh1Itih3stVA46TeRkqjj4XHFfbV8dZhEg", // Yay, another API key to leak in public code.
    notifySelf: true, // Because apparently, I need to notify myself that I exist.
    presence: true // Sure, let’s keep track of who's present like we’re taking attendance in kindergarten.
  });

  // Assuming piesocket is already initialized and connected
  channel = await piesocket.subscribe("chat-room" + roomCode);
  UID = Math.random().toString(36).substring(2, 8);
  username = UID;

  /* RPC LISTENER */
  channel.listen("new_message", function (data) {
    // Ignore messages we sent
    if (data.sender == UID && !data.text) return;

    /* Message */
    if (data.sender && data.text) {
      document.getElementById("chatLog").innerText += `${data.sender}: ${data.text}\n`;
      chatBox.scrollTop = chatBox.scrollHeight; // Auto-scroll to the bottom
    }

    /* Tower placed */
    if (data.event && data.object) {
      if (data.event == "towerPlaced") {
        gameBoard[data.object.y][data.object.x] = data.object.tower;

        // Draw the tower on the canvas
        drawTower(data.object.x, data.object.y, data.object.tower);

        console.log(`Network tower placed at (${data.object.x}, ${data.object.y}).`);
      }
    }

    /* Client joined and requests game state */
    if (data.event == "requestGameState" && data.sender && role == "Defense") {
      let gameState = {
        board: gameBoard,
        chat: document.getElementById("chatLog").innerHTML
      };

      sendData("syncGameState", gameState, data.sender);
    }

    /* Host sent game state */
    if (data.event == "syncGameState" && data.recipient == UID && data.object) {
      gameBoard = data.object.board;
      console.log("board updated");
      drawBoard();
      document.getElementById("chatLog").innerHTML = data.object.chat;
    }
  });
  /* END RPC LISTENER */

  /* Request board and chat from host */
  sendData("requestGameState", null);
}

connectChat(); // Call the chat connection function

/* Keep outside connect function */
function sendMessage(username, message) {
  channel.publish("new_message", {
    sender: username,
    text: message
  });
}

document.getElementById("sendMessage").onclick = () => {
  const messageInput = document.getElementById("message");
  const message = messageInput.value.trim();
  if (message) {
    // Use the sendMessage function from your PieHost code
    sendMessage(username, message);
    messageInput.value = ""; // Clear input
  }
};

function sendData(e, o = null, r = null) {
  channel.publish("new_message", {
    event: e,
    object: o,
    recipient: r,
    sender: UID
  });
}

document.getElementById("role").innerHTML = "Role: " + role;

//Defense can select towers on the left, attack can select enemies on the left.
//Attack selects enemies and selects "spawn" (there will be preset enemy spawn points.)

// Function to load and display towers
function loadUI() {
  const container = document.querySelector("#towerContainer");
  container.innerHTML = ""; // Clear existing content

  if (role === "Defense") {
    loadTowers();
    console.log("Attempted loading of towers");
  } else if (role === "Attack") {
    loadEnemies();
  }
}

function loadTowers() {
  const towerContainer = document.querySelector(".left-nav");
  defenseTowers.forEach((tower) => {
    const towerBtn = document.createElement("button");
    towerBtn.classList.add("tower-btn");
    towerBtn.innerText = `${tower.name} (Cost: ${tower.cost})`;
    towerBtn.onclick = () => showTowerInfo(tower);
    towerContainer.appendChild(towerBtn);
  });
}

function loadEnemies() {
  const enemyContainer = document.querySelector(".left-nav");
  attackEnemies.forEach((enemy) => {
    const enemyBtn = document.createElement("button");
    enemyBtn.classList.add("enemy-btn");
    enemyBtn.innerText = `${enemy.name} (HP: ${enemy.health})`;
    enemyBtn.onclick = () => showEnemyInfo(enemy);
    enemyContainer.appendChild(enemyBtn);
  });
}

function showEnemyInfo(enemy) {
  player.selectedEnemy = enemy;

  // Clear pre-existing info divs
  document.querySelectorAll(".enemy-info").forEach((i) => {
    i.remove();
  });

  const infoContainer = document.createElement("div");
  infoContainer.classList.add("enemy-info");
  infoContainer.innerHTML = `
    <h4>${enemy.name}</h4>
    <p>HP: ${enemy.health}</p>
    <p>Speed: ${enemy.speed}</p>
    <button class="spawn-btn">Spawn</button>
  `;
  document.body.appendChild(infoContainer);
  infoContainer.style.position = "absolute";
  infoContainer.style.left = `${event.pageX}px`;
  infoContainer.style.top = `${event.pageY}px`;

  document.addEventListener(
    "keydown",
    (e) => {
      if (e.key == "Escape" && infoContainer) {
        document.body.removeChild(infoContainer);
      }
    },
    { once: true }
  );
}

// Function to show tower info in a context menu
function showTowerInfo(tower) {
  player.selectedTower = tower;

  // Clear pre-existing info divs
  document.querySelectorAll(".tower-info").forEach((i) => {
    i.remove();
  });

  const infoContainer = document.createElement("div");
  infoContainer.classList.add("tower-info");

  infoContainer.innerHTML = `
    <h4>${tower.name}</h4>
    <p>Cost: ${tower.cost}</p>
    <p>Damage: ${tower.damage}</p>
    <p>Range: ${tower.range}</p>
    <p>Fire Rate: ${tower.fireRate} seconds</p>
  `;

  // Append to the body and position below the clicked button
  document.body.appendChild(infoContainer);
  infoContainer.style.position = "absolute";
  infoContainer.style.left = `${event.pageX}px`;
  infoContainer.style.top = `${event.pageY}px`;

  // Remove info when clicking elsewhere
  document.addEventListener(
    "keydown",
    (e) => {
      if (infoContainer && e.key == "Escape") {
        document.body.removeChild(infoContainer);
        player.selectedTower = null;
      }
    },
    { once: true }
  );
}

loadUI();

// Get the canvas element and context
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

// Set canvas size
canvas.width = window.innerWidth * 0.8; // Set to 80% of the window width
canvas.height = window.innerHeight * 0.8; // Set to 80% of the window height

// Function to draw the grid
function drawGrid() {
  const rows = 20; // Number of rows
  const cols = 20; // Number of columns
  const cellWidth = canvas.width / cols; // Width of each cell
  const cellHeight = canvas.height / rows; // Height of each cell

  // Set grid line color and width
  ctx.strokeStyle = "#ccc";
  ctx.lineWidth = 1;

  // Draw vertical lines
  for (let x = 0; x <= cols; x++) {
    ctx.beginPath();
    ctx.moveTo(x * cellWidth, 0);
    ctx.lineTo(x * cellWidth, canvas.height);
    ctx.stroke();
  }

  // Draw horizontal lines
  for (let y = 0; y <= rows; y++) {
    ctx.beginPath();
    ctx.moveTo(0, y * cellHeight);
    ctx.lineTo(canvas.width, y * cellHeight);
    ctx.stroke();
  }
}

// Call the function to draw the grid
drawGrid();

// Initialize a 2D array representing the game board
const rows = 20;
const cols = 20;
var gameBoard = Array.from({ length: rows }, () => Array(cols).fill(null)); // Each cell starts as 'null'

// Function to draw the tower on the grid
function drawTower(x, y, tower) {
  const cellWidth = canvas.width / cols;
  const cellHeight = canvas.height / rows;

  // Draw the tower as a filled rectangle in the center of the cell
  ctx.fillStyle = "blue"; // Change to a color representing the tower
  ctx.fillRect(x * cellWidth + cellWidth / 4, y * cellHeight + cellHeight / 4, cellWidth / 2, cellHeight / 2);

  // Optionally, add text to indicate tower details, e.g., range or name
  ctx.fillStyle = "white";
  ctx.font = "10px Arial";
  ctx.fillText(tower.name, x * cellWidth + cellWidth / 4, y * cellHeight + cellHeight / 4 + 10);
}

// Sample function to draw enemies on the grid (if needed)
function drawEnemy(x, y, enemy) {
  const cellWidth = canvas.width / cols;
  const cellHeight = canvas.height / rows;

  // Draw the enemy as a filled circle in the center of the cell
  ctx.fillStyle = "red"; // Change to a color representing the enemy
  ctx.beginPath();
  ctx.arc(
    x * cellWidth + cellWidth / 2,
    y * cellHeight + cellHeight / 2,
    Math.min(cellWidth, cellHeight) / 4,
    0,
    Math.PI * 2
  );
  ctx.fill();

  // Optionally, add text to indicate enemy details
  ctx.fillStyle = "white";
  ctx.font = "10px Arial";
  ctx.fillText(enemy.name, x * cellWidth + cellWidth / 4, y * cellHeight + cellHeight / 4 + 10);
}

// Function to draw towers and enemies on the game board based on gameBoard array
function drawBoard() {
  console.log("drawing full board");
  // Clear the canvas first to prevent overlapping drawings
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Redraw the grid
  drawGrid();

  // Loop through each cell in gameBoard
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      const cell = gameBoard[y][x];
      if (cell) {
        if (cell.type === "tower") {
          drawTower(x, y, cell); // Pass cell info (like name) to drawTower
        } else if (cell.type === "enemy") {
          drawEnemy(x, y, cell); // Use a similar draw function for enemies
        }
      }
    }
  }
}

// Update canvas click handler to place a tower
canvas.onclick = (e) => {
  // Calculate the clicked cell position
  const cellWidth = canvas.offsetWidth / cols;
  const cellHeight = canvas.offsetHeight / rows;
  const x = Math.floor(e.offsetX / cellWidth);
  const y = Math.floor(e.offsetY / cellHeight);

  console.log(player.selectedTower, x, y);
  // Check if a tower is selected and the cell is empty
  if (player.selectedTower && gameBoard[y][x] === null && player.selectedTower.cost <= player.cash) {
    // Place the selected tower in the game board array
    gameBoard[y][x] = player.selectedTower;
    gameBoard[y][x].type = "tower";

    // Draw the tower on the canvas
    drawTower(x, y, player.selectedTower);

    // Deduct the tower cost from player's cash
    player.cash -= player.selectedTower.cost;

    console.log(`Tower placed at (${x}, ${y}). Player's remaining cash: ${player.cash}`);
    let dataObj = { x: x, y: y, tower: player.selectedTower };
    sendData("towerPlaced", dataObj);
  } else if (gameBoard[y][x] !== null) {
    console.log("This cell already has a tower or enemy.");
  }
};

// Draw grid initially
drawGrid();

/* Start of game */
var player = {
  cash: 100,
  selectedTower: null,
  selectedEnemy: null
};
