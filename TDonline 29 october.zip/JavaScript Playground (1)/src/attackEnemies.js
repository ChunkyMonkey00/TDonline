const attackEnemies = [
  {
    name: "Basic Enemy",
    health: 30,
    speed: 1,
    currentTile: null
  },
  {
    name: "Fast Enemy",
    health: 20,
    speed: 2,
    currentTile: null
  },
  {
    name: "Tank Enemy",
    health: 50,
    speed: 0.5,
    currentTile: null
  }
];
